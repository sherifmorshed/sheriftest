#!/usr/bin/env python3
"""
Regenerate the offline test harnesses from index.html.

They swap the real Firebase SDK for firebase-stub.js and seed three days of
readings plus three days of tank battery scanner readings, so the whole app —
every role, entry, chart, print, PDF — can be exercised with no Firebase
project and no network.

    python3 test_build.py

Produces test.html (admin), test_plant.html (Ras Gara operator),
test_petreco.html (PETRECO operator), test_tb.html (tank battery operator)
and test_viewer.html (an account in no role list).
Run it again after editing index.html, or the harnesses will test the old
version.
These are development files: do NOT deploy them.
"""
import json, os, random

HERE = os.path.dirname(os.path.abspath(__file__))

def make_day(date, seed):
    """One shift of plausible readings. PETRECO 2-11 m³/hr, Ras Gara 3-20,
    with Ras Gara's cumulative running as its own independent meter total."""
    random.seed(seed)
    rows, rc = {}, 0
    for i in range(24):
        p = random.randint(2, 11)
        r = random.randint(3, 20)
        rc += r
        rows[str(i)] = {"p": p, "r": r, "rc": rc}
    # A MAP keyed "0".."23", matching what the app writes. Firestore arrays are
    # atomic, so a map is what makes per-side merge writes possible.
    return {"date": date, "startHour": 6, "rows": rows,
            "updatedBy": "sherifmorshed", "updatedAt": {"__ts": 1}}

# T.B. 10/1 runs a 06:00 shift; the other four run 05:00.
TB_STARTS = {"tb10_1": 6, "tb6_1": 5, "tb6_2": 5, "tb8_1": 5, "tb8_2": 5}
TB_IDS = list(TB_STARTS)

def make_tb_docs(date, seed, partial=False, glitch=False):
    """One tank battery shift as FIVE documents, one per battery, keyed
    `date__batteryId` — the shape the app writes and the rules enforce.

    Nine scanner readings three hours apart give eight intervals. The scanner
    is a TOTALIZER: it only climbs, and production is the difference between
    consecutive readings.

    partial : stop after the 5th reading — the mid-shift state a phone is in
              for most of the day.
    glitch  : make one battery read LOWER than the reading before it, which is
              a meter reset and must be flagged, not summed."""
    random.seed(seed)
    docs = {}
    for bi, tid in enumerate(TB_IDS):
        total = random.randint(40000, 90000)
        rows = {}
        n = 5 if partial else 9
        for i in range(n):
            if glitch and bi == 2 and i == 4:
                total -= random.randint(500, 900)      # the reset
            else:
                total += random.randint(18, 55)        # three hours of production
            rows[str(i)] = {"s": round(total, 1), "w": random.randint(85, 165)}
        for i in range(n, 9):
            rows[str(i)] = {"s": None, "w": None}
        # Temperature, by hour offset from the shift start — at the scanner
        # times, every three hours, for every battery.
        step = 3
        temp = {}
        base = random.randint(38, 52)
        for o in range(0, 25, step):
            temp[str(o)] = base + random.randint(-4, 4)
        # Chemical injection, by hour offset, every SIX hours — a dose, not a
        # reading, so a partly-read day is short of doses too.
        chem = {}
        for o in range(0, 25, 6):
            if partial and o > 12:
                continue
            chem[str(o)] = round(random.uniform(2, 9), 1)
        docs["tbReadings/" + date + "__" + tid] = {
            "date": date, "battery": tid, "startHour": TB_STARTS[tid], "rows": rows,
            "temp": temp, "chem": chem, "updatedBy": tid, "updatedAt": {"__ts": 1}}
    return docs


DATES = ["2026-08-18", "2026-08-19", "2026-08-20"]
store = {"rasGara/" + d: make_day(d, 11 + i) for i, d in enumerate(DATES)}
store["rasGaraMeta/info"] = {"dates": DATES, "count": len(DATES),
                             "updatedAt": {"__ts": 1}, "updatedBy": "test"}

# Tank batteries. Three days covering the three states worth looking at: a
# complete day, a day with a meter reset in it, and a part-filled day.
# Fourteen days so the admin breakdown, the day-over-day comparison and the
# range chips all have something real to work on. The last three are the states
# worth looking at: a clean day, a meter reset, and a part-filled day.
import datetime as _dt
TB_DATES = [(_dt.date(2026, 8, 7) + _dt.timedelta(days=i)).isoformat() for i in range(14)]
for i, d in enumerate(TB_DATES):
    store.update(make_tb_docs(
        d, 31 + i,
        glitch=(d == TB_DATES[-2]),
        partial=(d == TB_DATES[-1])))
# Three days of DAILY-ONLY history: a day total imported from the scanner
# sheet with no three-hour readings behind it. These must total and compare
# like any other day, but must never show three-hour detail they do not have.
for i, d in enumerate(["2026-08-04", "2026-08-05", "2026-08-06"]):
    # Mapped by name, not zipped: TB_IDS is ordered with 10/1 first and a zip
    # silently gave 10/1 the 6/1 figure.
    for tid, v in {"tb6_1": 5219, "tb6_2": 2968, "tb8_1": 3769,
                   "tb8_2": 5380, "tb10_1": 1390}.items():
        store["tbReadings/" + d + "__" + tid] = {
            "date": d, "battery": tid, "dayTotal": v + i * 7,
            "source": "scanner sheet Aug 2026",
            "updatedBy": "import", "updatedAt": {"__ts": 1}}
TB_DATES = sorted(set(TB_DATES + ["2026-08-04", "2026-08-05", "2026-08-06"]))

# PETRECO scanners: five meters read every three hours from 06:00 — eight
# periods a day — plus a remark.
#
# Three days, deliberately in three different states:
#   18th  the OLD twelve-hour shape (`v`), as every day before v15 is stored.
#         It must still total and still compare over 12 and 24 hours, and show
#         "12 h only" on a 3- or 6-hour card.
#   19th  a complete three-hour day (`q`), eight periods.
#   20th  five of eight periods — the state a shift is in at 21:00, and the one
#         that must not be compared against a finished yesterday.
PF_METERS = ["p29bis", "pgb1", "pgb3", "plotf", "pmotf", "psicies"]
PF_DATES = ["2026-08-18", "2026-08-19", "2026-08-20"]
PF_FILLED = {"2026-08-19": 8, "2026-08-20": 5}
for i, d in enumerate(PF_DATES):
    random.seed(500 + i)
    for m in PF_METERS:
        doc = {"date": d, "meter": m, "updatedBy": "petreco", "updatedAt": {"__ts": 1}}
        if d in PF_FILLED:
            n = PF_FILLED[d]
            if m in ("p29bis", "pgb1", "pgb3"):
                # drains: the scanner's TOTALIZER reading, nine a day; the 20th
                # opens on the 19th's closing reading
                base = {"p29bis": 512300, "pgb1": 288150, "pgb3": 97420}[m]
                if d == "2026-08-20":
                    prev = store["pfReadings/2026-08-19__" + m]["r"]
                    run = prev["8"]
                else:
                    run = base
                r = {}
                for k in range(n + 1):
                    if k > 0:
                        run += random.randint(220, 700)
                    if not (d == "2026-08-20" and k == 0):   # opening comes from yesterday
                        r[str(k)] = run
                doc["r"] = r
            else:
                doc["q"] = {str(k): random.randint(220, 700) for k in range(n)}
        else:
            doc["v"] = {"0": random.randint(900, 2600), "1": random.randint(900, 2600)}
        store["pfReadings/" + d + "__" + m] = doc
store["pfReadings/2026-08-19__remarks"] = {
    "date": "2026-08-19", "meter": "remarks",
    "text": "T.B 6/1 Scanner back to service at 3:00 pm under observation",
    "updatedBy": "petreco", "updatedAt": {"__ts": 1}}
store["pfReadingsMeta/info"] = {"dates": PF_DATES, "count": len(PF_DATES),
                                "updatedAt": {"__ts": 1}, "updatedBy": "test"}

# ── Pump station sample: every pump's state at every three-hour reading.
# Duty swaps, one breakdown that is still out (with its reason), one that was
# repaired and came back, a PM on record, a pump nobody reports, and the last
# day read only as far as its scanner.
def _pump_state(bat, i, d, r):
    n = int(d[-2:]); t = n * 10 + r          # a sortable moment
    if bat == "tb6_1":
        return ("in" if t < 140 else "sb") if i == 0 else ("sb" if t < 140 else "in")
    if bat == "tb6_2":
        if i == 3: return "in" if t < 142 else "out"
        return ["in", "sb", "in"][i]
    if bat == "tb8_1":
        if i == 1: return "in" if t < 93 else ("out" if t < 110 else "sb")
        if i == 2: return "sb" if t < 93 else "in"
        return "in"
    if bat == "tb8_2":
        return ["in", "sb", None][i]
    if bat == "tb10_1":
        if i == 5: return "in" if t < 181 else "out"
        return ["in", "in", "in", "sb", "sb"][i]
WHY = {("tb6_2", 3, "2026-08-14", 2): "Motor tripped on overload — bearing damaged, spare requested",
       ("tb8_1", 1, "2026-08-09", 3): "Mechanical seal leaking",
       ("tb10_1", 5, "2026-08-18", 1): "كسر في الكوبلنج — في انتظار الورشة"}
NPUMPS = {"tb6_1": 2, "tb6_2": 4, "tb8_1": 3, "tb8_2": 3, "tb10_1": 6}
for d in TB_DATES:
    if d < "2026-08-07":
        continue
    for bat, npump in NPUMPS.items():
        key = "tbReadings/" + d + "__" + bat
        if key not in store:
            continue
        last_row = 4 if d == TB_DATES[-1] else 8
        pumps, why = {}, {}
        for i in range(npump):
            for r in range(last_row + 1):
                st = _pump_state(bat, i, d, r)
                if st:
                    pumps.setdefault(str(i), {})[str(r)] = st
                w = WHY.get((bat, i, d, r))
                if w:
                    why.setdefault(str(i), {})[str(r)] = w
        store[key]["pumps"] = pumps
        if why:
            store[key]["pumpWhy"] = why
        if bat == "tb8_1" and d == "2026-08-12":
            store[key]["pumpPM"] = {"0": True}

# ── T.B. 10/1 station measurements: the 19th fully read, the 20th as far as
# 12:00 — rounds at 05, 09, 12, 15, 18, 21, 00, 03, 05.
def _meas(n):
    return {"t7": round(1.0 + 0.05 * n, 2), "t9": round(1.35 + 0.03 * n, 2),
            "s1n": 4, "s1": "emulsion", "s2n": 11, "s2": "emulsion" if n % 3 else "oil",
            "tT2": 50 + n % 4, "tSL": 37 + n % 3, "pS1": 2.4, "pS2": 2.4, "pSL": 10,
            "qOil": 120 + 5 * n, "qDr": 145 + 3 * n, "skim": str(5 + n % 5), "hp1": "off", "hp2": "on",
            "h1S": "on", "h1T": 82 + n % 3, "h1F": 11.5, "h2S": "on", "h2T": 80 + n % 4, "h2F": 12,
            "h4S": "on", "h4T": 84, "h4F": 10.5, "oilR": "on"}
for d, upto in (("2026-08-19", 9), ("2026-08-20", 3)):
    key = "tbReadings/" + d + "__tb10_1"
    if key in store:
        store[key]["meas"] = {str(k): _meas(k) for k in range(upto)}

# ── T.B. 10/1 high-pressure pumps, one state a day: HP 1 runs, HP 2 is the
# spare — out on the 16th and 17th, back to standby on the 18th; the 20th
# not recorded yet.
for d in TB_DATES:
    if d < "2026-08-07" or d == TB_DATES[-1]:
        continue
    key = "tbReadings/" + d + "__tb10_1"
    if key not in store:
        continue
    n = int(d[-2:])
    store[key]["pumpsDaily"] = {"0": "in", "1": "out" if n in (16, 17) else "sb",
        # v42 equipment: heaters on (Sigma 2 out from the 18th), the heater
        # treater off, compressors A on / B off, chemical on, fire pumps standby
        "8": "in", "9": "out" if n >= 18 else "in", "10": "in", "11": "sb",
        "12": "in", "13": "sb", "14": "in", "15": "sb", "16": "sb", "17": "sb", "18": "sb"}
    if n == 16:
        store[key]["pumpsDailyWhy"] = {"1": "Seal leak — workshop"}
    if n == 18:
        store[key].setdefault("pumpsDailyWhy", {})["9"] = "Burner flame failure"

store["tbReadingsMeta/info"] = {"dates": TB_DATES, "count": len(TB_DATES),
                                "updatedAt": {"__ts": 1}, "updatedBy": "test"}

idx = open(os.path.join(HERE, 'index.html'), encoding='utf-8').read()

for tag in ('firebase-app-compat.js', 'firebase-firestore-compat.js', 'firebase-auth-compat.js'):
    idx = idx.replace('<script src="./%s"></script>' % tag, '')

# The boot guard refuses to start while the config is still a placeholder,
# which is exactly what we want in production and exactly what we must defeat
# here. These values are never sent anywhere — the stub answers every call.
for a, b in [('"PASTE_API_KEY"', '"test-key"'),
             ('"PASTE_PROJECT_ID.firebaseapp.com"', '"test.firebaseapp.com"'),
             ('"PASTE_PROJECT_ID.firebasestorage.app"', '"test.appspot.com"'),
             ('"PASTE_PROJECT_ID"', '"test"'),
             ('"PASTE_SENDER_ID"', '"1"'),
             ('"PASTE_APP_ID"', '"1:1:web:1"')]:
    idx = idx.replace(a, b)

ANCHOR = '<script src="./html2canvas.min.js"></script>'
ADMIN = {"email": "sherifmorshed@gmail.com", "uid": "a1"}
for name, user, st in [('test.html',         ADMIN,                                        store),
                       ('test_plant.html',   {"email": "rasgara@petrobel.org", "uid":"p1"}, store),
                       ('test_petreco.html', {"email": "petreco@petrobel.org", "uid":"e1"}, store),
                       # The tank battery operator. The point of this one is
                       # what it must NOT show: no tab bar, no Production tab,
                       # and no Ras Gara listener started at all — the rules
                       # would refuse that read and paint a false error in the
                       # footer of a perfectly healthy app.
                       ('test_tb.html',      {"email": "tb6-2@petrobel.org", "uid":"t1"}, store),
                       ('test_pf.html',      {"email": "petreco@petrobel.org", "uid":"p1"}, store),
                       # Signs in but is in no role list. The rules refuse it
                       # everything, so it must get the no-access page and start
                       # no listener at all.
                       ('test_viewer.html',  {"email": "visitor@petrobel.org", "uid":"v1"}, store),
                       # A brand-new Firebase project: connected, authenticated,
                       # and completely empty. This is the state a fresh
                       # deployment is actually in, and the one where "no data"
                       # and "not connected" look identical if the footer status
                       # is wrong.
                       ('test_empty.html',   ADMIN,                                        {}),
                       # A project holding a few unrelated days but NOT the 2026
                       # record — what a real deployment looks like after someone
                       # has tried the app out. `test.html` is the same store;
                       # this alias exists so the case has a name, because gating
                       # the history import on "the project is empty" hid it here
                       # permanently and that is exactly the bug that shipped.
                       ('test_stray.html',   ADMIN,                                        store)]:
    seed = 'window.__SEED__=' + json.dumps({"user": user, "store": st}) + ';'
    out = idx.replace(ANCHOR, ANCHOR + '\n<script>' + seed + '</script>'
                                       '\n<script src="./firebase-stub.js"></script>')
    open(os.path.join(HERE, name), 'w', encoding='utf-8').write(out)
    print('wrote', name)
