#!/usr/bin/env python3
"""
Regenerate the LONG-RUN test harnesses from index.html.

test_build.py seeds three days. Three days cannot exercise the daily record:
no month has a second month to compare against, the 90-day chip never appears,
the day-by-day chart never gets dense enough to drop its point markers, and the
custom month dropdown has one entry. This builds ~120 generated days spanning
five calendar months instead.

    python3 test_build_hist.py

Produces test_hist.html (admin) and test_hist_rg.html (Ras Gara operator).
Run it again after editing index.html.
These are development files: do NOT deploy them.

The days are GENERATED, not real readings. They are shaped to hit the cases the
record has to survive rather than to be plausible production data:

  · five calendar months, so "This month" and the month dropdown have something
    to choose between;
  · gaps — days missing entirely, which is what a real record looks like;
  · days where only ONE side reported, which must show "—" rather than a
    full-size difference against the other side's implied zero;
  · differences in both directions, so the red/green colouring is exercised
    both ways.
"""
import json, os, random
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))

FIRST, LAST = date(2026, 4, 8), date(2026, 8, 8)
GAPS = {date(2026, 5, 23), date(2026, 5, 26), date(2026, 6, 24), date(2026, 7, 14)}
P_ONLY = {date(2026, 6, 2)}          # Ras Gara never reported
R_ONLY = {date(2026, 4, 25)}         # PETRECO never reported

random.seed(20260408)

def make_day(d):
    """24 hourly readings. Ras Gara runs a little above or below PETRECO by the
    day, so the Difference column lands on both colours across the range."""
    bias = random.choice([-1, 1]) * random.uniform(0, 1.6)
    rows = {}
    for h in range(24):
        base = random.uniform(4.5, 8.0)
        p = None if d in R_ONLY else round(base, 1)
        r = None if d in P_ONLY else round(max(0.5, base + bias + random.uniform(-1.2, 1.2)), 1)
        if p is None and r is None:
            continue
        rows[str(h)] = {"p": p, "r": r, "rc": None}
    return rows

store, dates = {}, []
d = FIRST
while d <= LAST:
    if d not in GAPS:
        iso = d.isoformat()
        dates.append(iso)
        store['rasGara/' + iso] = {"date": iso, "startHour": 6, "rows": make_day(d),
                                   "updatedBy": "generated", "updatedAt": {"__ts": 1}}
    d += timedelta(days=1)
store['rasGaraMeta/info'] = {"dates": dates, "count": len(dates),
                             "updatedAt": {"__ts": 1}, "updatedBy": "generated"}

# The same span of tank battery days, so the record report and its 30/90/All
# ranges are exercised against a real range rather than a fortnight. Nine
# readings per battery; every ~11th day left part-filled and every ~17th given
# a meter reset, so the report's warnings and its "averages exclude N part
# day(s)" line have something to report.
# T.B. 10/1 runs a 06:00 shift; the other four run 05:00.
TB_STARTS = {"tb10_1": 6, "tb6_1": 5, "tb6_2": 5, "tb8_1": 5, "tb8_2": 5}
TB_IDS = list(TB_STARTS)
tb_dates = []
d, k = FIRST, 0
while d <= LAST:
    if d not in GAPS:
        iso = d.isoformat()
        tb_dates.append(iso)
        random.seed(9000 + k)
        partial = (k % 11 == 10)
        glitch  = (k % 17 == 16)
        for bi, tid in enumerate(TB_IDS):
            total = random.randint(40000, 90000)
            rows_ = {}
            n = 5 if partial else 9
            for i in range(n):
                if glitch and bi == 1 and i == 3:
                    total -= random.randint(400, 900)
                else:
                    total += random.randint(18, 55)
                rows_[str(i)] = {"s": round(total, 1), "w": random.randint(85, 165)}
            for i in range(n, 9):
                rows_[str(i)] = {"s": None, "w": None}
            store['tbReadings/' + iso + '__' + tid] = {
                "date": iso, "battery": tid, "startHour": TB_STARTS[tid], "rows": rows_,
                "updatedBy": tid, "updatedAt": {"__ts": 1}}
        k += 1
    d += timedelta(days=1)
store['tbReadingsMeta/info'] = {"dates": tb_dates, "count": len(tb_dates),
                                "updatedAt": {"__ts": 1}, "updatedBy": "generated"}

idx = open(os.path.join(HERE, 'index.html'), encoding='utf-8').read()

for tag in ('firebase-app-compat.js', 'firebase-firestore-compat.js',
            'firebase-auth-compat.js'):
    idx = idx.replace('<script src="./%s"></script>' % tag, '')

for a, b in [('"PASTE_API_KEY"', '"test-key"'),
             ('"PASTE_PROJECT_ID.firebaseapp.com"', '"test.firebaseapp.com"'),
             ('"PASTE_PROJECT_ID.firebasestorage.app"', '"test.appspot.com"'),
             ('"PASTE_PROJECT_ID"', '"test"'),
             ('"PASTE_SENDER_ID"', '"1"'),
             ('"PASTE_APP_ID"', '"1:1:web:1"')]:
    idx = idx.replace(a, b)

ANCHOR = '<script src="./html2canvas.min.js"></script>'
for name, user in [('test_hist.html',    {"email": "sherifmorshed@gmail.com", "uid": "a1"}),
                   ('test_hist_rg.html', {"email": "rasgara@petrobel.org",    "uid": "p1"})]:
    seed = 'window.__SEED__=' + json.dumps({"user": user, "store": store}) + ';'
    out = idx.replace(ANCHOR, ANCHOR + '\n<script>' + seed + '</script>'
                                       '\n<script src="./firebase-stub.js"></script>')
    open(os.path.join(HERE, name), 'w', encoding='utf-8').write(out)
    print('wrote', name, '—', len(dates), 'days across 5 months')
